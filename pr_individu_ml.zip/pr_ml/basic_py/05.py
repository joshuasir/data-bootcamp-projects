num = int(input())

while (num!=42):
    print(num)
    num = int(input())