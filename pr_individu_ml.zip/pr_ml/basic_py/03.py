n = int(input())
prime = {}


for k in range(1,n+1):
    num = int(input())
    j = 2
    
    if num in prime.keys():
        print('NO')
        continue
    
    while (j*j < num+1):
        if num % j == 0:
            print("NO")
            break
        elif (j+1)*(j+1)>=num:
            print("YES")
            i= num*2
            while(i < 1e9+1):
                prime[str(i)] = 1
                i+=i
        j+=1
            