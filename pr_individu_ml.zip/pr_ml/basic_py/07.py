n = int(input())
num = {}
for i in range(1,n+1):
    num = list(input())
    num = list(map(int, num))
    print(sum(num))
    