num = 0
for i in range(1,7):
    num+=input()
    
print(num/6)